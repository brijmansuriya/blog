<div class="hero container page__container text-center text-md-left py-112pt">
    <h1 class="text-white text-shadow">Easy , Effective and Enjoy Learning</h1>
    <p class="lead measure-hero-lead mx-auto mx-md-0 text-white text-shadow mb-48pt">Education beyond exams</p>

   
    </p>

</div>