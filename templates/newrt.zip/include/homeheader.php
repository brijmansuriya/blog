
        <div id="header" class="mdk-header mdk-header--bg-dark bg-dark js-mdk-header mb-0"
            data-effects="parallax-background waterfall" data-fixed data-condenses>
            <div class="mdk-header__bg">
                <div class="mdk-header__bg-front" style="background-image: url(public/images/photodune-4161018-group-of-students-m.jpg);"></div>
                
            </div>
            <div class="mdk-header__content justify-content-center">

                <div class="navbar navbar-expand navbar-dark-pickled-bluewood bg-transparent will-fade-background"
                    id="default-navbar" data-primary>

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler w-auto mr-16pt d-block rounded-0" type="button" data-toggle="sidebar">
                        <span class="material-icons">short_text</span>
                    </button>

                    <!-- Navbar Brand -->
                   <!-- Navbar Brand -->
                   <a href="index.php" class="navbar-brand mr-16pt">
                        <span class="avatar avatar-sm navbar-brand-icon mr-0 mr-lg-8pt">
                            <span class="rounded">
                                <img
                                    src="public/images/log-small.png" alt="logo"
                                    class="img-fluid" /></span>
                        </span>
                        
                    </a>

                    <ul class="nav navbar-nav d-none d-sm-flex flex justify-content-start ml-8pt">
                                                                 
                        <li class="nav-item active">
                            <a href="index.php" class="nav-link">My Courses</a>
                        </li>
                       
                        <li class="nav-item active">
                            <a href="edit_profile.php" class="nav-link">My Profile</a>
                        </li>
                        <li class="nav-item active">
                            <a href="index.php" class="nav-link">About Newrit</a>
                        </li> 
                        <li class="nav-item active">
                            <a href="#" class="nav-link">Contact</a>
                        </li>
                    </ul>

                    
                    <ul class="nav navbar-nav ml-auto mr-0">

                    <li class="nav-item">
                                <a href="#"
                                   class="btn btn-outline-white">Asia Primary School</a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="login.php"
                                   class="btn btn-outline-white">Login</a>
                            </li>
                        </ul>


                </div>

                <?php include('include/banner.php'); ?>
            </div>
        </div>
